from django.http import HttpResponse
from django.shortcuts import render

def home_view(request):
    return render(request, "home.html", {})

def contact_view(request):
    return render(request, "contact.html", {})

def about_view(request):
    my_context = {
        "my_text": "This is about us",
        "my_number": 123,
        "my_list": [1313, 4231, 312, "Abc"],
        "my_html": "<h1>Hello World</h1>"
    }
    return render(request, "about.html", {})

def social_view(request):
    return HttpResponse("<h1>Social Page</h1>")